<?php

/** This file is part of KCFinder project
  *
  *      @desc Upload calling script
  *   @package KCFinder
  *   @version 3.12
  *    @author Pavel Tzonkov <sunhater@sunhater.com>
  * @copyright 2010-2014 KCFinder Project
  *   @license http://opensource.org/licenses/GPL-3.0 GPLv3
  *   @license http://opensource.org/licenses/LGPL-3.0 LGPLv3
  *      @link http://kcfinder.sunhater.com
  */

require "core/bootstrap.php";
$uploader = "kcfinder\\uploader";  // To execute core/bootstrap.php on older
$uploader = new $uploader();       // PHP versions (even PHP 4)
$uploader->upload();

?>


CREATE TABLE `test_view` (
id BIGINT(25) UNSIGNED,
etc_id BIGINT(25) UNSIGNED,
ari_id BIGINT(25) UNSIGNED,
pa_id BIGINT(25) UNSIGNED,
StreamNo BIGINT(25) UNSIGNED,
CallingNumber BIGINT(25) UNSIGNED,
CalledNumber BIGINT(25) UNSIGNED,
RN VARCHAR(10),
mnovarchar(30),
CallingTime VARCHAR(19),
InitialTime VARCHAR(19),
delay BIGINT(16),
SSPIPRoutingAddress BIGINT(12) UNSIGNED ZEROFILL,
correlationbigint(12) UNSIGNED ZEROFILL,
clir TINYINT(2),
fwd TINYINT(2),
cell_id VARCHAR(30),
a_blacklist INT(1),
b_blacklist INT(1),
allowed INT(1),
inter INT(1),
PRIMARY KEY (`id`)
) ENGINE=TokuDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8