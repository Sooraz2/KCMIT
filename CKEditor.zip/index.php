<html>


<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
  
 
 <script src="ckeditor/ckeditor.js"> </script>

  
<textarea id='Test'> </textarea>


</html>

<script>


   
   

CKEDITOR.replace( 'Test' );





// ckeditor/config.js
/*
CKEDITOR.editorConfig = function( config ) {
   config.filebrowserBrowseUrl = '/ckfinder/ckfinder.html';
   config.filebrowserImageBrowseUrl = '/ckfinder/ckfinder.html?type=Images';
   config.filebrowserFlashBrowseUrl = '/ckfinder/ckfinder.html?type=Flash';
   config.filebrowserUploadUrl = '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files';
   config.filebrowserImageUploadUrl = '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images';
   config.filebrowserFlashUploadUrl = '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash';
};
*/

/*
 CKEDITOR.replace( 'Test',
{
	filebrowserBrowseUrl : '/ckfinder/ckfinder.html',
	filebrowserImageBrowseUrl : '/ckfinder/ckfinder.html?type=Images',
	filebrowserFlashBrowseUrl : '/ckfinder/ckfinder.html?type=Flash',
	filebrowserUploadUrl : '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
	filebrowserImageUploadUrl : '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
	filebrowserFlashUploadUrl : '/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'
});
*/





//var editor = CKEDITOR.replace( 'editor1' );
//CKFinder.setupCKEditor( editor, '/ckfinder/' );
</script>